package com.example.rrice.Megaman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MegamanApplication {

	public static void main(String[] args) {
		SpringApplication.run(MegamanApplication.class, args);
	}

}

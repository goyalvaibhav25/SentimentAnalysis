import { Component, OnInit } from '@angular/core';

 

@Component({

  selector: 'app-intent',

  templateUrl: './intent.component.html',

  styleUrls: ['./intent.component.css']

})

export class IntentComponent implements OnInit {

 

  constructor() { }

 

  ngOnInit() {

  }

 

}

 
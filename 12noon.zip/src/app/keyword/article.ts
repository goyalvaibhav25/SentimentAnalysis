export interface Article {
    "userId": number;
    "id": number;
    "title" : string;
    "completed": boolean;
    // "_id":string;
    // "sequence":string;
    // "text":string;
    // "keywords": JSON;
    // "Sentiments":JSON;
    // "callid":string;
}
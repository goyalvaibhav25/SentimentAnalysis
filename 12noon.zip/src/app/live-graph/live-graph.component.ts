import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { chart } from 'highcharts';
import * as Highcharts from 'highcharts';
import { ApiService } from 'src/app/api.service';
import { style, color } from '../../../node_modules/@types/d3';


@Component({
  selector: 'app-live-graph',
  templateUrl: './live-graph.component.html',
  styleUrls: ['./live-graph.component.css']
})

export class LiveGraphComponent implements OnInit {
  month = ["abc"];
  price = ["123"];
  chart = [];
  @ViewChild('chartline') chartline: ElementRef;
  linechart: Highcharts.ChartObject;
  graphData: any;
  stringArray:any[];
  jsonData:any;
  graphValue:any;
  data: any;
  array1: number[]=[];
  abc:number;

  constructor(private apiService: ApiService) { }
  ngOnInit() {
    // this.chart = new Chart('canvas', {
    //   type: 'line',
    //   data: {
    //     labels: this.month,
    //     datasets: [
    //       {
    //         data: this.price,
    //         borderColor: '#3cba9f',
    //         fill: false
    //       }
    //     ]
    //   },
    //   options: {
    //     legend: {
    //       display: false
    //     },
    //     scales: {
    //       xAxes: [{
    //         display: true
    //       }],
    //       yAxes: [{
    //         display: true
    //       }],
    //     }
    //   }
    // });
  }

ngAfterViewInit() {
  const lines: Highcharts.Options = {
    chart: {
      type: 'line'
    },
    title: {
      text: 'Live Analysis',
      style: {
        color: '#3781C2',
        fontFamily: 'TimesNewRoman',
        fontWeight: 'bold'
      }

    },
    xAxis: {
      title: {
        text: 'Time', style: { fontWeight: 'bold', fontFamily: 'TimesNewRoman' }
      }
      , categories: ['1min', '2min', '3min', '4min']
    },
    yAxis: {
      title: {
        text: 'Count of emotions', style: { fontWeight: 'bold', fontFamily: 'TimesNewRoman' }
      }
    },
    series: [{
      name: 'Sad',
      data: [1, 6, 3, 5], color: '#FFBB33'
    }, {
      name: 'Happy',
      data: [4, 7, 8, 3], color: '#BC87CA'
    },
    {
      name: 'Angry',
      data: [0, 2, 1, 6], color: '#D2AF4A'
    },
    {
      name: 'Love',
      data: [3, 4, 6, 2], color: '#F08080'
    }]
  };
    this.linechart = chart(this.chartline.nativeElement, lines);

  // this.apiService.getGraphData().subscribe((res: any) => {
  //   this.graphData = res;
  //   //console.log(JSON.stringify(this.graphData));
  //   this.jsonData = JSON.stringify(this.graphData);
  //   this.stringArray = this.jsonData.split(" ");
  //   //console.log(this.stringArray);
  //   this.graphValue=this.stringArray[10];
  //  // console.log(this.graphValue);
  //   this.data=Number(this.graphValue.split(""));
  //  // console.log(typeof this.data); 
  //   this.array1.push(this.data);
  //   console.log(this.array1);
  //   this.array1.push(10);
  //   this.array1.push(2);
  //   this.array1.push(3);
  // },
  // err => {
  //   console.log(err);
  // });
  // console.log(this.array1);
  //   const columnOptions: Highcharts.Options = {
  //     chart: {
  //       type: 'column'
  //     },
  //     title: {
  //       text: 'SENTIMENTS OF ON-GOING CALL',
  //       style: {
  //         color: '#3781C2',
  //         fontWeight: 'bold',
  //         fontFamily: 'TimesNewRoman'
  //       }
  //     },
  //     xAxis: {
  //       categories: ['Emotion']
  //     },
  //     yAxis: {
  //       title: {
  //         text: 'COUNT',
  //         style: { fontWeight: 'bold', fontFamily: 'TimesNewRoman' }
  //       }
  //     },
  //     series: [{
  //       name: 'Happy',
  //       data:  this.array1,
  //       color: 'green'
  //     },
  //     {
  //       name: 'SAD',
  //       data: this.array1,
  //       color: 'black'
  //     },
  //     {
  //       name: 'ANGRY',
  //       data: [7],
  //       color: 'red'
  //     },
  //     {
  //       name: 'NONE',
  //       data: [2],
  //       color: 'gray'
  //     }]
  //   };
  //   this.columnChart = chart(this.chartColumn.nativeElement, columnOptions);
   }
}
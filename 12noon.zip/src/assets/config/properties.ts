export const urlList = [
    {keyword:"Account", url:"https://www.google.com"},
    {keyword:"Bill", url:"https://www.facebook.com"}
]
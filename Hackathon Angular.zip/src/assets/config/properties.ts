export const urlList = [
    {keyword:"Account", url:"https://www.lex.com"},
    {keyword:"Bill", url:"https://www.google.com"}
]